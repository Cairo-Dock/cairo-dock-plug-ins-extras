#!/usr/bin/python

# This is a part of the external Translator (formally doCkranslator) applet for Cairo-Dock
#
# Author: Eduardo Mucelli Rezende Oliveira
# E-mail: edumucelli@gmail.com or eduardom@dcc.ufmg.br

def log (string):
    print "[+] doCkranslator: %s" % string
